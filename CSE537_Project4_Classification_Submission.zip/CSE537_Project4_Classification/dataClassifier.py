# dataClassifier.py
# -----------------
# Licensing Information: Please do not distribute or publish solutions to this
# project. You are free to use and extend these projects for educational
# purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
# John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html

# This file contains feature extraction methods and harness 
# code for data classification

import mostFrequent
import id3
import naiveBayes
import perceptron
import mira
import samples
import sys
import util
import argparse

TEST_SET_SIZE = 100
DIGIT_DATUM_WIDTH=28
DIGIT_DATUM_HEIGHT=28
FACE_DATUM_WIDTH=60
FACE_DATUM_HEIGHT=70


def basicFeatureExtractorDigit(datum):
  """
  Returns a set of pixel features indicating whether
  each pixel in the provided datum is white (0) or gray/black (1)
  """
  a = datum.getPixels()

  features = util.Counter()
  for x in range(DIGIT_DATUM_WIDTH):
    for y in range(DIGIT_DATUM_HEIGHT):
      if datum.getPixel(x, y) > 0:
        features[(x,y)] = 1
      else:
        features[(x,y)] = 0
  return features

def basicFeatureExtractorFace(datum):
  """
  Returns a set of pixel features indicating whether
  each pixel in the provided datum is an edge (1) or no edge (0)
  """
  a = datum.getPixels()

  features = util.Counter()
  for x in range(FACE_DATUM_WIDTH):
    for y in range(FACE_DATUM_HEIGHT):
      if datum.getPixel(x, y) > 0:
        features[(x,y)] = 1
      else:
        features[(x,y)] = 0
  return features

def enhancedFeatureExtractorDigit(datum):
  """
  Your feature extraction playground.
  
  You should return a util.Counter() of features
  for this datum (datum is of type samples.Datum).
  
  In addition to the raw pixels, this extractor adds binary encodings of
  foreground components, enclosed background regions (holes), ink density,
  bounding-box shape, symmetry, coarse-zone density, center of mass, scan-line
  crossings, and regional ink density.  Multi-valued properties use one-hot
  binary features so they remain compatible with the binary Naive Bayes model.
  ##
  """
  features = basicFeatureExtractorDigit(datum)
  pixels = [[datum.getPixel(x, y) > 0 for y in range(DIGIT_DATUM_HEIGHT)]
            for x in range(DIGIT_DATUM_WIDTH)]

  def componentCount(target, ignoreBorder=False):
    seen = set()
    components = 0
    for x in range(DIGIT_DATUM_WIDTH):
      for y in range(DIGIT_DATUM_HEIGHT):
        if (x, y) in seen or pixels[x][y] != target:
          continue
        stack = [(x, y)]
        seen.add((x, y))
        touchesBorder = False
        while stack:
          cx, cy = stack.pop()
          if cx in (0, DIGIT_DATUM_WIDTH - 1) or cy in (0, DIGIT_DATUM_HEIGHT - 1):
            touchesBorder = True
          for nx, ny in ((cx-1, cy), (cx+1, cy), (cx, cy-1), (cx, cy+1)):
            if (0 <= nx < DIGIT_DATUM_WIDTH and
                0 <= ny < DIGIT_DATUM_HEIGHT and
                (nx, ny) not in seen and pixels[nx][ny] == target):
              seen.add((nx, ny))
              stack.append((nx, ny))
        if not ignoreBorder or not touchesBorder:
          components += 1
    return components

  foregroundComponents = componentCount(True)
  holes = componentCount(False, ignoreBorder=True)
  for value in range(1, 4):
    features[('foreground-components', value)] = int(
        foregroundComponents == value if value < 3 else foregroundComponents >= 3)
  for value in range(3):
    features[('holes', value)] = int(
        holes == value if value < 2 else holes >= 2)

  onPixels = [(x, y) for x in range(DIGIT_DATUM_WIDTH)
              for y in range(DIGIT_DATUM_HEIGHT) if pixels[x][y]]
  density = len(onPixels) / float(DIGIT_DATUM_WIDTH * DIGIT_DATUM_HEIGHT)
  for threshold in (0.10, 0.15, 0.20, 0.25, 0.30):
    features[('density-at-least', threshold)] = int(density >= threshold)

  if onPixels:
    xs = [x for x, _ in onPixels]
    ys = [y for _, y in onPixels]
    width = max(xs) - min(xs) + 1
    height = max(ys) - min(ys) + 1
    ratio = width / float(height)
  else:
    ratio = 1.0
  features[('bbox', 'narrow')] = int(ratio < 0.55)
  features[('bbox', 'medium')] = int(0.55 <= ratio < 0.80)
  features[('bbox', 'wide')] = int(ratio >= 0.80)

  horizontalMismatch = sum(
      pixels[x][y] != pixels[DIGIT_DATUM_WIDTH - 1 - x][y]
      for x in range(DIGIT_DATUM_WIDTH // 2)
      for y in range(DIGIT_DATUM_HEIGHT))
  verticalMismatch = sum(
      pixels[x][y] != pixels[x][DIGIT_DATUM_HEIGHT - 1 - y]
      for x in range(DIGIT_DATUM_WIDTH)
      for y in range(DIGIT_DATUM_HEIGHT // 2))
  features[('symmetry', 'horizontal')] = int(horizontalMismatch < 75)
  features[('symmetry', 'vertical')] = int(verticalMismatch < 75)

  # Coarse spatial summaries capture shape while being less sensitive than
  # individual pixels to small shifts in a writer's stroke placement.
  for zoneX in range(4):
    for zoneY in range(4):
      ink = sum(pixels[x][y]
                for x in range(zoneX * 7, (zoneX + 1) * 7)
                for y in range(zoneY * 7, (zoneY + 1) * 7))
      for threshold in (5, 12, 20):
        features[('zone-density', zoneX, zoneY, threshold)] = int(
            ink >= threshold)

  if onPixels:
    centerX = sum(x for x, _ in onPixels) / float(len(onPixels))
    centerY = sum(y for _, y in onPixels) / float(len(onPixels))
  else:
    centerX = centerY = 13.5
  for threshold in (10, 12, 14, 16, 18):
    features[('center-x-at-least', threshold)] = int(centerX >= threshold)
    features[('center-y-at-least', threshold)] = int(centerY >= threshold)

  # The number of off/on transitions through representative scan lines is a
  # useful proxy for open strokes versus loops.
  for y in (7, 10, 14, 18, 21):
    transitions = sum(pixels[x][y] != pixels[x - 1][y]
                      for x in range(1, DIGIT_DATUM_WIDTH))
    for threshold in (2, 4, 6):
      features[('horizontal-crossings', y, threshold)] = int(
          transitions >= threshold)
  for x in (7, 10, 14, 18, 21):
    transitions = sum(pixels[x][y] != pixels[x][y - 1]
                      for y in range(1, DIGIT_DATUM_HEIGHT))
    for threshold in (2, 4, 6):
      features[('vertical-crossings', x, threshold)] = int(
          transitions >= threshold)

  regions = {
      'top': (0, 28, 0, 14), 'bottom': (0, 28, 14, 28),
      'left': (0, 14, 0, 28), 'right': (14, 28, 0, 28),
  }
  for name, (x0, x1, y0, y1) in regions.items():
    ink = sum(pixels[x][y] for x in range(x0, x1)
              for y in range(y0, y1))
    for threshold in (30, 50, 70, 90):
      features[('region-density', name, threshold)] = int(ink >= threshold)
  
  return features


def contestFeatureExtractorDigit(datum):
  """
  Specify features to use for the minicontest
  """
  features =  basicFeatureExtractorDigit(datum)
  return features

def enhancedFeatureExtractorFace(datum):
  """
  Your feature extraction playground for faces.
  It is your choice to modify this.
  """
  features =  basicFeatureExtractorFace(datum)
  return features

def analysis(classifier, guesses, testLabels, testData, rawTestData, printImage):
  """
  This function is called after learning.
  Include any code that you want here to help you analyze your results.
  
  Use the printImage(<list of pixels>) function to visualize features.
  
  An example of use has been given to you.
  
  - classifier is the trained classifier
  - guesses is the list of labels predicted by your classifier on the test set
  - testLabels is the list of true labels
  - testData is the list of training datapoints (as util.Counter of features)
  - rawTestData is the list of training datapoints (as samples.Datum)
  - printImage is a method to visualize the features 
  (see its use in the odds ratio part in runClassifier method)
  
  This code won't be evaluated. It is for your own optional use
  (and you can modify the signature if you want).
  """
  
  # Put any code here...
  # Example of use:
  for i in range(len(guesses)):
      prediction = guesses[i]
      truth = testLabels[i]
      if (prediction != truth):
          print("===================================")
          print("Mistake on example %d" % i )
          print("Predicted %d; truth is %d" % (prediction, truth))
          print("Image: ")
          print(rawTestData[i])
          break


## =====================
## You don't have to modify any code below.
## =====================


class ImagePrinter:
    def __init__(self, width, height):
      self.width = width
      self.height = height

    def printImage(self, pixels):
      """
      Prints a Datum object that contains all pixels in the 
      provided list of pixels.  This will serve as a helper function
      to the analysis function you write.
      
      Pixels should take the form 
      [(2,2), (2, 3), ...] 
      where each tuple represents a pixel.
      """
      image = samples.Datum(None,self.width,self.height)
      for pix in pixels:
        try:
            # This is so that new features that you could define which 
            # which are not of the form of (x,y) will not break
            # this image printer...
            x,y = pix
            image.pixels[x][y] = 2
        except:
            print("new features:", pix)
            continue
      print(image)

def default(str):
  return str + ' [Default: %default]'

def readCommand( argv ):
  "Processes the command used to run from the command line."

  from optparse import OptionParser
  parser = OptionParser(USAGE_STRING)

  parser.add_option('-c', '--classifier', help=default('The type of classifier'), choices=['mostFrequent', 'nb', 'naiveBayes', 'perceptron', 'mira', 'minicontest', 'id3'], default='mostFrequent')
  parser.add_option('-d', '--data', help=default('Dataset to use'), choices=['digits', 'faces'], default='digits')
  parser.add_option('-t', '--training', help=default('The size of the training set'), default=100, type="int")
  parser.add_option('-f', '--features', help=default('Whether to use enhanced features'), default=False, action="store_true")
  parser.add_option('-o', '--odds', help=default('Whether to compute odds ratios'), default=False, action="store_true")
  parser.add_option('-1', '--label1', help=default("First label in an odds ratio comparison"), default=0, type="int")
  parser.add_option('-2', '--label2', help=default("Second label in an odds ratio comparison"), default=1, type="int")
  parser.add_option('-w', '--weights', help=default('Whether to print weights'), default=False, action="store_true")
  parser.add_option('-k', '--smoothing', help=default("Smoothing parameter (ignored when using --autotune)"), type="float", default=2.0)
  parser.add_option('-a', '--autotune', help=default("Whether to automatically tune hyperparameters"), default=False, action="store_true")
  parser.add_option('-i', '--iterations', help=default("Maximum iterations to run training"), default=3, type="int")
  parser.add_option('-s', '--test', help=default("Amount of test data to use"), default=TEST_SET_SIZE, type="int")
  parser.add_option('-p', '--pruning', help='Enable decision tree pruning', action='store_true', default=False)
  
  options, otherjunk = parser.parse_args(argv)
  if len(otherjunk) != 0: raise Exception('Command line input not understood: ' + str(otherjunk))
  args = {}

  
  # Set up variables according to the command line input.
  print("Doing classification")
  print("--------------------")
  print("data:\t\t" + options.data)
  print("classifier:\t\t" + options.classifier)
  if not options.classifier == 'minicontest':
    print("using enhanced features?:\t" + str(options.features))
  else:
    print("using minicontest feature extractor")
  print("training set size:\t" + str(options.training))
  if(options.data=="digits"):
    printImage = ImagePrinter(DIGIT_DATUM_WIDTH, DIGIT_DATUM_HEIGHT).printImage
    if (options.features):
      featureFunction = enhancedFeatureExtractorDigit
    else:
      featureFunction = basicFeatureExtractorDigit
    if (options.classifier == 'minicontest'):
      featureFunction = contestFeatureExtractorDigit
  elif(options.data=="faces"):
    printImage = ImagePrinter(FACE_DATUM_WIDTH, FACE_DATUM_HEIGHT).printImage
    if (options.features):
      featureFunction = enhancedFeatureExtractorFace
    else:
      featureFunction = basicFeatureExtractorFace      
  else:
    print("Unknown dataset", options.data)
    print(USAGE_STRING)
    sys.exit(2)
    
  if(options.data=="digits"):
    legalLabels = range(10)
  else:
    legalLabels = range(2)
    
  if options.training <= 0:
    print("Training set size should be a positive integer (you provided: %d)" % options.training)
    print(USAGE_STRING)
    sys.exit(2)
    
  if options.smoothing <= 0:
    print("Please provide a positive number for smoothing (you provided: %f)" % options.smoothing)
    print(USAGE_STRING)
    sys.exit(2)
    
  if options.odds:
    if options.label1 not in legalLabels or options.label2 not in legalLabels:
      print("Didn't provide a legal labels for the odds ratio: (%d,%d)" % (options.label1, options.label2))
      print(USAGE_STRING)
      sys.exit(2)

  if(options.classifier == "mostFrequent"):
    classifier = mostFrequent.MostFrequentClassifier(legalLabels)
  elif(options.classifier == "id3"):
    classifier = id3.ID3Classifier(legalLabels)
    classifier.setPruning(options.pruning)
  elif(options.classifier == "naiveBayes" or options.classifier == "nb"):
    classifier = naiveBayes.NaiveBayesClassifier(legalLabels)
    classifier.setSmoothing(options.smoothing)
    if (options.autotune):
        print("using automatic tuning for naivebayes")
        classifier.automaticTuning = True
    else:
        print("using smoothing parameter k=%f for naivebayes" %  options.smoothing)
  elif(options.classifier == "perceptron"):
    classifier = perceptron.PerceptronClassifier(legalLabels,options.iterations)
  elif(options.classifier == "mira"):
    classifier = mira.MiraClassifier(legalLabels, options.iterations)
    if (options.autotune):
        print("using automatic tuning for MIRA")
        classifier.automaticTuning = True
    else:
        print("using default C=0.001 for MIRA")
  elif(options.classifier == 'minicontest'):
    import minicontest
    classifier = minicontest.contestClassifier(legalLabels)
  else:
    print("Unknown classifier:", options.classifier)
    print(USAGE_STRING)
    
    sys.exit(2)

  args['classifier'] = classifier
  args['featureFunction'] = featureFunction
  args['printImage'] = printImage
  
  return args, options

USAGE_STRING = """
  USAGE:      python dataClassifier.py <options>
  EXAMPLES:   (1) python dataClassifier.py
                  - trains the default mostFrequent classifier on the digit dataset
                  using the default 100 training examples and
                  then test the classifier on test data
              (2) python dataClassifier.py -c naiveBayes -d digits -t 1000 -f -o -1 3 -2 6 -k 2.5
                  - would run the naive Bayes classifier on 1000 training examples
                  using the enhancedFeatureExtractorDigits function to get the features
                  on the faces dataset, would use the smoothing parameter equals to 2.5, would
                  test the classifier on the test data and performs an odd ratio analysis
                  with label1=3 vs. label2=6
                 """

# Main harness code

def runClassifier(args, options):

  featureFunction = args['featureFunction']
  classifier = args['classifier']
  printImage = args['printImage']
      
  # Load data  
  numTraining = options.training
  numTest = options.test

  if(options.data=="faces"):
    rawTrainingData = samples.loadDataFile("facedata/facedatatrain", numTraining,FACE_DATUM_WIDTH,FACE_DATUM_HEIGHT)
    trainingLabels = samples.loadLabelsFile("facedata/facedatatrainlabels", numTraining)
    rawValidationData = samples.loadDataFile("facedata/facedatatrain", numTest,FACE_DATUM_WIDTH,FACE_DATUM_HEIGHT)
    validationLabels = samples.loadLabelsFile("facedata/facedatatrainlabels", numTest)
    rawTestData = samples.loadDataFile("facedata/facedatatest", numTest,FACE_DATUM_WIDTH,FACE_DATUM_HEIGHT)
    testLabels = samples.loadLabelsFile("facedata/facedatatestlabels", numTest)
  else:
    rawTrainingData = samples.loadDataFile("digitdata/trainingimages", numTraining,DIGIT_DATUM_WIDTH,DIGIT_DATUM_HEIGHT)
    trainingLabels = samples.loadLabelsFile("digitdata/traininglabels", numTraining)
    rawValidationData = samples.loadDataFile("digitdata/validationimages", numTest,DIGIT_DATUM_WIDTH,DIGIT_DATUM_HEIGHT)
    validationLabels = samples.loadLabelsFile("digitdata/validationlabels", numTest)
    rawTestData = samples.loadDataFile("digitdata/testimages", numTest,DIGIT_DATUM_WIDTH,DIGIT_DATUM_HEIGHT)
    testLabels = samples.loadLabelsFile("digitdata/testlabels", numTest)
    
  
  # Extract features
  print("Extracting features...")
  trainingData = list(map(featureFunction, rawTrainingData))
  validationData = list(map(featureFunction, rawValidationData))
  testData = list(map(featureFunction, rawTestData))
  
  # Conduct training and testing
  print("Training...")
  classifier.train(trainingData, trainingLabels, validationData, validationLabels)
  print("Validating...")
  guesses = classifier.classify(validationData)
  correct = [guesses[i] == validationLabels[i] for i in range(len(validationLabels))].count(True)
  print(str(correct), ("correct out of " + str(len(validationLabels)) + " (%.1f%%).") % (100.0 * correct / len(validationLabels)))
  print("Testing...")
  guesses = classifier.classify(testData)
  correct = [guesses[i] == testLabels[i] for i in range(len(testLabels))].count(True)
  print(str(correct), ("correct out of " + str(len(testLabels)) + " (%.1f%%).") % (100.0 * correct / len(testLabels)))
  analysis(classifier, guesses, testLabels, testData, rawTestData, printImage)
  
  # do odds ratio computation if specified at command line
  if((options.odds) & (options.classifier == "naiveBayes" or (options.classifier == "nb")) ):
    label1, label2 = options.label1, options.label2
    features_odds = classifier.findHighOddsFeatures(label1,label2)
    if(options.classifier == "naiveBayes" or options.classifier == "nb"):
      string3 = "=== Features with highest odd ratio of label %d over label %d ===" % (label1, label2)
    else:
      string3 = "=== Features for which weight(label %d)-weight(label %d) is biggest ===" % (label1, label2)    
      
    print(string3)
    printImage(features_odds)

  if((options.weights) & (options.classifier == "perceptron")):
    for l in classifier.legalLabels:
      features_weights = classifier.findHighWeightFeatures(l)
      print ("=== Features with high weight for label %d ==="%l)
      printImage(features_weights)

if __name__ == '__main__':
  # Read input
  args, options = readCommand( sys.argv[1:] ) 
  # Run classifier
  runClassifier(args, options)
